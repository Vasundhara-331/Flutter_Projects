package com.example.image_gallery

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
