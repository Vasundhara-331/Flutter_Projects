class ImageModel {
  final String path;

  ImageModel({required this.path});

  factory ImageModel.fromJson(String json) {
    return ImageModel(
      path: json,
    );
  }
}
