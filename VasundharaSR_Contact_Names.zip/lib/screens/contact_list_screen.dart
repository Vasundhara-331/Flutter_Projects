import 'package:flutter/material.dart';
import '../models/contact.dart';
import 'add_contact_screen.dart';
import '../widgets/contact_tile.dart';

class ContactListScreen extends StatefulWidget {
  @override
  _ContactListScreenState createState() => _ContactListScreenState();
}

class _ContactListScreenState extends State<ContactListScreen> {
  List<Contact> contacts = [];

  void _addContact(Contact contact) {
    setState(() {
      contacts.add(contact);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Contacts'),
      ),
      body: ListView.builder(
        itemCount: contacts.length,
        itemBuilder: (context, index) {
          return ContactTile(contact: contacts[index]);
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final newContact = await Navigator.push<Contact>(
            context,
            MaterialPageRoute(
              builder: (context) => AddContactScreen(),
            ),
          );
          if (newContact != null) {
            _addContact(newContact);
          }
        },
        child: Icon(Icons.add),
      ),
    );
  }
}
