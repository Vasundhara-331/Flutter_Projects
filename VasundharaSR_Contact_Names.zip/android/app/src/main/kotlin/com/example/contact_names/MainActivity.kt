package com.example.contact_names

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
